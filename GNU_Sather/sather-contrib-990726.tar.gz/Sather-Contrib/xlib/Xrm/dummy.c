Xrm_dummy(){}
