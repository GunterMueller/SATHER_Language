/* access to the X Athena Widgets for Sather
 * (c) 1995/01/16 - 1995/01/18 by Erik Schnetter
 */

#include <System/header.h>
#include <X11/Intrinsic.h>
#include <X11/Xaw/AsciiText.h>
#include <X11/Xaw/Box.h>
#include <X11/Xaw/Cardinals.h>
#include <X11/Xaw/Command.h>
#include <X11/Xaw/Dialog.h>
#include <X11/Xaw/Form.h>
#include <X11/Xaw/Grip.h>
#include <X11/Xaw/Label.h>
#include <X11/Xaw/List.h>
#include <X11/Xaw/MenuButton.h>
#include <X11/Xaw/Paned.h>
#include <X11/Xaw/Panner.h>
#include <X11/Xaw/Porthole.h>
#include <X11/Xaw/Repeater.h>
#include <X11/Xaw/Reports.h>
#include <X11/Xaw/Scrollbar.h>
#include <X11/Xaw/Simple.h>
#include <X11/Xaw/SimpleMenu.h>
#include <X11/Xaw/Sme.h>
#include <X11/Xaw/SmeBSB.h>
#include <X11/Xaw/SmeLine.h>
#include <X11/Xaw/StripChart.h>
#include <X11/Xaw/Text.h>
#include <X11/Xaw/Toggle.h>
#include <X11/Xaw/Tree.h>
#include <X11/Xaw/Viewport.h>



WidgetClass Xaw_asciiTextWidgetClass()
{ return asciiTextWidgetClass; }

WidgetClass Xaw_boxWidgetClass()
{ return boxWidgetClass; }

WidgetClass Xaw_commandWidgetClass()
{ return commandWidgetClass; }

WidgetClass Xaw_dialogWidgetClass()
{ return dialogWidgetClass; }

WidgetClass Xaw_formWidgetClass()
{ return formWidgetClass; }

WidgetClass Xaw_gripWidgetClass()
{ return gripWidgetClass; }

WidgetClass Xaw_labelWidgetClass()
{ return labelWidgetClass; }

WidgetClass Xaw_listWidgetClass()
{ return listWidgetClass; }

WidgetClass Xaw_menuButtonWidgetClass()
{ return menuButtonWidgetClass; }

WidgetClass Xaw_panedWidgetClass()
{ return panedWidgetClass; }

WidgetClass Xaw_pannerWidgetClass()
{ return pannerWidgetClass; }

WidgetClass Xaw_portholeWidgetClass()
{ return portholeWidgetClass; }

WidgetClass Xaw_repeaterWidgetClass()
{ return repeaterWidgetClass; }

WidgetClass Xaw_scrollbarWidgetClass()
{ return scrollbarWidgetClass; }

WidgetClass Xaw_simpleWidgetClass()
{ return simpleWidgetClass; }

WidgetClass Xaw_simpleMenuWidgetClass()
{ return simpleMenuWidgetClass; }

WidgetClass Xaw_smeObjectClass()
{ return smeObjectClass; }

WidgetClass Xaw_smeBSBObjectClass()
{ return smeBSBObjectClass; }

WidgetClass Xaw_smeLineObjectClass()
{ return smeLineObjectClass; }

WidgetClass Xaw_stripChartWidgetClass()
{ return stripChartWidgetClass; }

WidgetClass Xaw_textWidgetClass()
{ return textWidgetClass; }

WidgetClass Xaw_toggleWidgetClass()
{ return toggleWidgetClass; }

WidgetClass Xaw_treeWidgetClass()
{ return treeWidgetClass; }

WidgetClass Xaw_viewportWidgetClass()
{ return viewportWidgetClass; }
