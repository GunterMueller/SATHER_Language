/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/09 - 1995/03/10 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include <X11/cursorfont.h>
#include "header.h"



INT X_CreateFontCursor (Display* display, INT shape)
{
  return XCreateFontCursor (display, shape);
}

INT X_CreatePixmapCursor
  (Display* display, Pixmap source, Pixmap mask, XColor* fg, XColor* bg,
   INT x, INT y)
{
  return XCreatePixmapCursor (display, source, mask, fg, bg, x, y);
}

INT X_CreateGlyphCursor
  (Display* display, Font source_font, Font mask_font,
   INT source_char, INT mask_char, XColor* fg, XColor* bg)
{
  return XCreateGlyphCursor
    (display, source_font, mask_font, source_char, mask_char, fg, bg);
}



void X_FreeCursor (Display* display, INT cursor)
{
  XFreeCursor (display, cursor);
}



void RecolorCursor (Display* display, INT cursor, XColor* fg, XColor* bg)
{
  XRecolorCursor (display, cursor, fg, bg);
}
