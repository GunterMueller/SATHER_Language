/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_MappingEvent_request_set (XMappingEvent* event, INT request)
{ event->request = request; }

void X_MappingEvent_first_keycode_set (XMappingEvent* event, INT first_keycode)
{ event->first_keycode = first_keycode; }

void X_MappingEvent_count_set (XMappingEvent* event, INT count)
{ event->count = count; }



INT X_MappingEvent_request_get (XMappingEvent* event)
{ return event->request; }

INT X_MappingEvent_first_keycode_get (XMappingEvent* event)
{ return event->first_keycode; }

INT X_MappingEvent_count_get (XMappingEvent* event)
{ return event->count; }
