/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/08 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_WindowAttributes_x_get (XWindowAttributes* attributes)
{ return attributes->x; }

INT X_WindowAttributes_y_get (XWindowAttributes* attributes)
{ return attributes->y; }

INT X_WindowAttributes_width_get (XWindowAttributes* attributes)
{ return attributes->width; }

INT X_WindowAttributes_height_get (XWindowAttributes* attributes)
{ return attributes->height; }

INT X_WindowAttributes_depth_get (XWindowAttributes* attributes)
{ return attributes->depth; }

Visual* X_WindowAttributes_visual_get (XWindowAttributes* attributes)
{ return attributes->visual; }

INT X_WindowAttributes_root_get (XWindowAttributes* attributes)
{ return attributes->root; }

INT X_WindowAttributes_class_get (XWindowAttributes* attributes)
{ return attributes->class; }

INT X_WindowAttributes_bit_gravity_get (XWindowAttributes* attributes)
{ return attributes->bit_gravity; }

INT X_WindowAttributes_win_gravity_get (XWindowAttributes* attributes)
{ return attributes->win_gravity; }

INT X_WindowAttributes_backing_store_get (XWindowAttributes* attributes)
{ return attributes->backing_store; }

INT X_WindowAttributes_backing_planes_get (XWindowAttributes* attributes)
{ return attributes->backing_planes; }

INT X_WindowAttributes_backing_pixel_get (XWindowAttributes* attributes)
{ return attributes->backing_pixel; }

BOOL X_WindowAttributes_save_under_get (XWindowAttributes* attributes)
{ return attributes->save_under; }

INT X_WindowAttributes_colormap_get (XWindowAttributes* attributes)
{ return attributes->colormap; }

BOOL X_WindowAttributes_map_installed_get (XWindowAttributes* attributes)
{ return attributes->map_installed; }

INT X_WindowAttributes_all_event_masks_get (XWindowAttributes* attributes)
{ return attributes->all_event_masks; }

INT X_WindowAttributes_your_event_mask_get (XWindowAttributes* attributes)
{ return attributes->your_event_mask; }

INT X_WindowAttributes_do_not_propagate_mask_get (XWindowAttributes* attributes)
{ return attributes->do_not_propagate_mask; }

BOOL X_WindowAttributes_override_redirect_get (XWindowAttributes* attributes)
{ return attributes->override_redirect; }

Screen* X_WindowAttributes_screen_get (XWindowAttributes* attributes)
{ return attributes->screen; }
