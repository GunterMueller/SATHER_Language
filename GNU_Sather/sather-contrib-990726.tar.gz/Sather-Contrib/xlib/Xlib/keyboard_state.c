/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/03/14 - 1995/03/14 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_KeyboardState_size (void)
{ return (sizeof(XKeyboardState)+sizeof(INT)-1)/sizeof(INT); }



INT X_KeyboardState_key_click_percent_get (XKeyboardState* keyboard_state)
{ return keyboard_state->key_click_percent; }

INT X_KeyboardState_bell_percent_get (XKeyboardState* keyboard_state)
{ return keyboard_state->bell_percent; }

INT X_KeyboardState_bell_pitch_get (XKeyboardState* keyboard_state)
{ return keyboard_state->bell_pitch; }

INT X_KeyboardState_bell_duration_get (XKeyboardState* keyboard_state)
{ return keyboard_state->bell_duration; }

INT X_KeyboardState_led_mask_get (XKeyboardState* keyboard_state)
{ return keyboard_state->led_mask; }

INT X_KeyboardState_global_auto_repeat_get (XKeyboardState* keyboard_state)
{ return keyboard_state->global_auto_repeat; }

void X_KeyboardState_auto_repeats_get (XKeyboardState* keyboard_state, CHAR* chars)
{
  int i;
  for(i=32; i--;)
    chars[i] = keyboard_state->auto_repeats[i];
}
