/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/05 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



XCharStruct* X_CharStruct_index (XCharStruct* char_struct, INT index)
{ return char_struct+index; }



INT X_CharStruct_lbearing_get (XCharStruct* char_struct)
{ return char_struct->lbearing; }

INT X_CharStruct_rbearing_get (XCharStruct* char_struct)
{ return char_struct->rbearing; }

INT X_CharStruct_width_get (XCharStruct* char_struct)
{ return char_struct->width; }

INT X_CharStruct_ascent_get (XCharStruct* char_struct)
{ return char_struct->ascent; }

INT X_CharStruct_descent_get (XCharStruct* char_struct)
{ return char_struct->descent; }

INT X_CharStruct_attributes_get (XCharStruct* char_struct)
{ return char_struct->attributes; }
