/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/08 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



XExtData* X_ScreenFormat_ext_data_get (ScreenFormat* format)
{ return format->ext_data; }

INT X_ScreenFormat_depth_get (ScreenFormat* format)
{ return format->depth; }

INT X_ScreenFormat_bits_per_pixel_get (ScreenFormat* format)
{ return format->bits_per_pixel; }

INT X_ScreenFormat_scanline_pad_get (ScreenFormat* format)
{ return format->scanline_pad; }
