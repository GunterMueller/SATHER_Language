/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_NoExposeEvent_drawable_set (XNoExposeEvent* event, INT drawable)
{ event->drawable = drawable; }

void X_NoExposeEvent_major_code_set (XNoExposeEvent* event, INT major_code)
{ event->major_code = major_code; }

void X_NoExposeEvent_minor_code_set (XNoExposeEvent* event, INT minor_code)
{ event->minor_code = minor_code; }



INT X_NoExposeEvent_drawable_get (XNoExposeEvent* event)
{ return event->drawable; }

INT X_NoExposeEvent_major_code_get (XNoExposeEvent* event)
{ return event->major_code; }

INT X_NoExposeEvent_minor_code_get (XNoExposeEvent* event)
{ return event->minor_code; }
