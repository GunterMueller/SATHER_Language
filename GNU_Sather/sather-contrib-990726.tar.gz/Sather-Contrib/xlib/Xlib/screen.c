/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/22 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_BlackPixelOfScreen(Screen* screen)
{
  return BlackPixelOfScreen(screen);
}

INT X_WhitePixelOfScreen(Screen* screen)
{
  return WhitePixelOfScreen(screen);
}

INT X_CellsOfScreen(Screen* screen)
{
  return CellsOfScreen(screen);
}

INT X_DefaultColormapOfScreen(Screen* screen)
{
  return DefaultColormapOfScreen(screen);
}

INT X_DefaultDepthOfScreen(Screen* screen)
{
  return DefaultDepthOfScreen(screen);
}

Visual* X_DefaultVisualOfScreen(Screen* screen)
{
  return DefaultVisualOfScreen(screen);
}

INT X_DoesBackingStore(Screen* screen)
{
  return DoesBackingStore(screen);
}

char X_DoesSaveUnders(Screen* screen)
{
  return DoesSaveUnders(screen);
}

Display* X_DisplayOfScreen(Screen* screen)
{
  return DisplayOfScreen(screen);
}

INT X_EventMaskOfScreen(Screen* screen)
{
  return EventMaskOfScreen(screen);
}

INT X_HeightOfScreen(Screen* screen)
{
  return HeightOfScreen(screen);
}

INT X_HeightMMOfScreen(Screen* screen)
{
  return HeightMMOfScreen(screen);
}

INT X_MaxCmapsOfScreen(Screen* screen)
{
  return MaxCmapsOfScreen(screen);
}

INT X_MinCmapsOfScreen(Screen* screen)
{
  return MinCmapsOfScreen(screen);
}

INT X_PlanesOfScreen(Screen* screen)
{
  return PlanesOfScreen(screen);
}

INT X_RootWindowOfScreen(Screen* screen)
{
  return RootWindowOfScreen(screen);
}

INT X_WidthOfScreen(Screen* screen)
{
  return WidthOfScreen(screen);
}

INT X_WidthMMOfScreen(Screen* screen)
{
  return WidthMMOfScreen(screen);
}
