/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ConfigureRequestEvent_window_set (XConfigureRequestEvent* event, INT window)
{ event->window = window; }

void X_ConfigureRequestEvent_x_set (XConfigureRequestEvent* event, INT x)
{ event->x = x; }

void X_ConfigureRequestEvent_y_set (XConfigureRequestEvent* event, INT y)
{ event->y = y; }

void X_ConfigureRequestEvent_width_set (XConfigureRequestEvent* event, INT width)
{ event->width = width; }

void X_ConfigureRequestEvent_height_set (XConfigureRequestEvent* event, INT height)
{ event->height = height; }

void X_ConfigureRequestEvent_border_width_set (XConfigureRequestEvent* event, INT border_width)
{ event->border_width = border_width; }

void X_ConfigureRequestEvent_above_set (XConfigureRequestEvent* event, INT above)
{ event->above = above; }

void X_ConfigureRequestEvent_detail_set (XConfigureRequestEvent* event, INT detail)
{ event->detail = detail; }

void X_ConfigureRequestEvent_value_mask_set (XConfigureRequestEvent* event, INT value_mask)
{ event->value_mask = value_mask; }



INT X_ConfigureRequestEvent_window_get (XConfigureRequestEvent* event)
{ return event->window; }

INT X_ConfigureRequestEvent_x_get (XConfigureRequestEvent* event)
{ return event->x; }

INT X_ConfigureRequestEvent_y_get (XConfigureRequestEvent* event)
{ return event->y; }

INT X_ConfigureRequestEvent_width_get (XConfigureRequestEvent* event)
{ return event->width; }

INT X_ConfigureRequestEvent_height_get (XConfigureRequestEvent* event)
{ return event->height; }

INT X_ConfigureRequestEvent_border_width_get (XConfigureRequestEvent* event)
{ return event->border_width; }

INT X_ConfigureRequestEvent_above_get (XConfigureRequestEvent* event)
{ return event->above; }

INT X_ConfigureRequestEvent_detail_get (XConfigureRequestEvent* event)
{ return event->detail; }

INT X_ConfigureRequestEvent_value_mask_get (XConfigureRequestEvent* event)
{ return event->value_mask; }
