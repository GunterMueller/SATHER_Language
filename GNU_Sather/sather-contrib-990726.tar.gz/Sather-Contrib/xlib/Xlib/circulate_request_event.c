/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_CirculateRequestEvent_window_set (XCirculateRequestEvent* event, INT window)
{ event->window = window; }

void X_CirculateRequestEvent_place_set (XCirculateRequestEvent* event, INT place)
{ event->place = place; }



INT X_CirculateRequestEvent_window_get (XCirculateRequestEvent* event)
{ return event->window; }

INT X_CirculateRequestEvent_place_get (XCirculateRequestEvent* event)
{ return event->place; }
