/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/10 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "header.h"



Region X_CreateRegion()
/* Region is struct* */
{
  return XCreateRegion();
}

void X_SetRegion (Display* display, GC gc, Region region)
/* Region and GC are struct* */
{
  XSetRegion (display, gc, region);
}

void X_DestroyRegion (Region region)
/* Region is struct* */
{
  XDestroyRegion (region);
}



Region X_PolygonRegion (INT* ints, INT npoints, INT fill_rule)
/* Region is struct* */
{
  XPoint* points = (XPoint*) alloca (npoints * sizeof(XPoint));
  int i;
  for (i=npoints; i--;) {
    points[i].x = ints[i*2  ];
    points[i].y = ints[i*2+1];
  }
  return XPolygonRegion (points, npoints, fill_rule);
}

void X_ClipBox (Region region, INT* ints)
/* Region is struct* */
{
  XRectangle rect;
  XClipBox (region, &rect);
  ints[0] = rect.x;
  ints[1] = rect.y;
  ints[2] = rect.width;
  ints[3] = rect.height;
}
