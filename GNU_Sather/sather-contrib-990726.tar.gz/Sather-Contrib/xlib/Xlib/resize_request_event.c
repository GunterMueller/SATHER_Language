/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ResizeRequestEvent_width_set (XResizeRequestEvent* event, INT width)
{ event->width = width; }

void X_ResizeRequestEvent_height_set (XResizeRequestEvent* event, INT height)
{ event->height = height; }



INT X_ResizeRequestEvent_width_get (XResizeRequestEvent* event)
{ return event->width; }

INT X_ResizeRequestEvent_height_get (XResizeRequestEvent* event)
{ return event->height; }
