/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_FocusChangeEvent_mode_set (XFocusChangeEvent* event, INT mode)
{ event->mode = mode; }

void X_FocusChangeEvent_detail_set (XFocusChangeEvent* event, INT detail)
{ event->detail = detail; }



INT X_FocusChangeEvent_mode_get (XFocusChangeEvent* event)
{ return event->mode; }

INT X_FocusChangeEvent_detail_get (XFocusChangeEvent* event)
{ return event->detail; }
