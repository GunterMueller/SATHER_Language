/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/07 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_GCValues_size (void)
{ return (sizeof(XGCValues)+sizeof(INT)-1)/sizeof(INT); }



void X_GCValues_function_set (XGCValues* gc_values, INT function)
{ gc_values->function = function; }

void X_GCValues_plane_mask_set (XGCValues* gc_values, INT plane_mask)
{ gc_values->plane_mask = plane_mask; }

void X_GCValues_foreground_set (XGCValues* gc_values, INT foreground)
{ gc_values->foreground = foreground; }

void X_GCValues_background_set (XGCValues* gc_values, INT background)
{ gc_values->background = background; }

void X_GCValues_line_width_set (XGCValues* gc_values, INT line_width)
{ gc_values->line_width = line_width; }

void X_GCValues_line_style_set (XGCValues* gc_values, INT line_style)
{ gc_values->line_style = line_style; }

void X_GCValues_cap_style_set (XGCValues* gc_values, INT cap_style)
{ gc_values->cap_style = cap_style; }

void X_GCValues_join_style_set (XGCValues* gc_values, INT join_style)
{ gc_values->join_style = join_style; }

void X_GCValues_fill_style_set (XGCValues* gc_values, INT fill_style)
{ gc_values->fill_style = fill_style; }

void X_GCValues_fill_rule_set (XGCValues* gc_values, INT fill_rule)
{ gc_values->fill_rule = fill_rule; }

void X_GCValues_arc_mode_set (XGCValues* gc_values, INT arc_mode)
{ gc_values->arc_mode = arc_mode; }

void X_GCValues_tile_set (XGCValues* gc_values, INT tile)
{ gc_values->tile = tile; }

void X_GCValues_stipple_set (XGCValues* gc_values, INT stipple)
{ gc_values->stipple = stipple; }

void X_GCValues_ts_x_origin_set (XGCValues* gc_values, INT ts_x_origin)
{ gc_values->ts_x_origin = ts_x_origin; }

void X_GCValues_ts_y_origin_set (XGCValues* gc_values, INT ts_y_origin)
{ gc_values->ts_y_origin = ts_y_origin; }

void X_GCValues_font_set (XGCValues* gc_values, INT font)
{ gc_values->font = font; }

void X_GCValues_subwindow_mode_set (XGCValues* gc_values, INT subwindow_mode)
{ gc_values->subwindow_mode = subwindow_mode; }

void X_GCValues_graphics_exposures_set (XGCValues* gc_values, BOOL graphics_exposures)
{ gc_values->graphics_exposures = graphics_exposures; }

void X_GCValues_clip_x_origin_set (XGCValues* gc_values, INT clip_x_origin)
{ gc_values->clip_x_origin = clip_x_origin; }

void X_GCValues_clip_y_origin_set (XGCValues* gc_values, INT clip_y_origin)
{ gc_values->clip_y_origin = clip_y_origin; }

void X_GCValues_clip_mask_set (XGCValues* gc_values, INT clip_mask)
{ gc_values->clip_mask = clip_mask; }

void X_GCValues_dash_offset_set (XGCValues* gc_values, INT dash_offset)
{ gc_values->dash_offset = dash_offset; }

void X_GCValues_dashes_set (XGCValues* gc_values, CHAR dashes)
{ gc_values->dashes = dashes; }



INT X_GCValues_function_get (XGCValues* gc_values)
{ return gc_values->function; }

INT X_GCValues_plane_mask_get (XGCValues* gc_values)
{ return gc_values->plane_mask; }

INT X_GCValues_foreground_get (XGCValues* gc_values)
{ return gc_values->foreground; }

INT X_GCValues_background_get (XGCValues* gc_values)
{ return gc_values->background; }

INT X_GCValues_line_width_get (XGCValues* gc_values)
{ return gc_values->line_width; }

INT X_GCValues_line_style_get (XGCValues* gc_values)
{ return gc_values->line_style; }

INT X_GCValues_cap_style_get (XGCValues* gc_values)
{ return gc_values->cap_style; }

INT X_GCValues_join_style_get (XGCValues* gc_values)
{ return gc_values->join_style; }

INT X_GCValues_fill_style_get (XGCValues* gc_values)
{ return gc_values->fill_style; }

INT X_GCValues_fill_rule_get (XGCValues* gc_values)
{ return gc_values->fill_rule; }

INT X_GCValues_arc_mode_get (XGCValues* gc_values)
{ return gc_values->arc_mode; }

INT X_GCValues_tile_get (XGCValues* gc_values)
{ return gc_values->tile; }

INT X_GCValues_stipple_get (XGCValues* gc_values)
{ return gc_values->stipple; }

INT X_GCValues_ts_x_origin_get (XGCValues* gc_values)
{ return gc_values->ts_x_origin; }

INT X_GCValues_ts_y_origin_get (XGCValues* gc_values)
{ return gc_values->ts_y_origin; }

INT X_GCValues_font_get (XGCValues* gc_values)
{ return gc_values->font; }

INT X_GCValues_subwindow_mode_get (XGCValues* gc_values)
{ return gc_values->subwindow_mode; }

BOOL X_GCValues_graphics_exposures_get (XGCValues* gc_values)
{ return gc_values->graphics_exposures; }

INT X_GCValues_clip_x_origin_get (XGCValues* gc_values)
{ return gc_values->clip_x_origin; }

INT X_GCValues_clip_y_origin_get (XGCValues* gc_values)
{ return gc_values->clip_y_origin; }

INT X_GCValues_clip_mask_get (XGCValues* gc_values)
{ return gc_values->clip_mask; }

INT X_GCValues_dash_offset_get (XGCValues* gc_values)
{ return gc_values->dash_offset; }

CHAR X_GCValues_dashes_get (XGCValues* gc_values)
{ return gc_values->dashes; }
