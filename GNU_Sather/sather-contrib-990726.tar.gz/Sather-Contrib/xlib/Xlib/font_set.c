/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/17 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"


#if XLIBVERSION != 1104

XFontSet X_CreateFontSet
  (Display* display, char* base_font_name_list, EXT_OB* exts, INT* ints)
/* XFontSet is struct* */
{
  char**   missing_charset_list;
  int      missing_charset_count;
  char*    def_string;
  XFontSet font_set;
  
  font_set = XCreateFontSet
    (display, base_font_name_list,
     &missing_charset_list, &missing_charset_count, &def_string);
  exts[0] = missing_charset_list;
  ints[0] = missing_charset_count;
  exts[1] = def_string;
  
  return font_set;
}

void XFreeFontSet (Display* display, XFontSet font_set)
/* XFontSet is struct* */
{
  XFreeFontSet (display, font_set);
}



INT X_FontsOfFontSet (XFontSet font_set, EXT_OB* exts)
{
  return XFontsOfFontSet (font_set, (XFontStruct***)exts, (char***)exts+1);
}

CHAR* X_BaseFontNameListOfFontSet (XFontSet font_set)
{
  return XBaseFontNameListOfFontSet (font_set);
}

CHAR* X_LocaleOfFontSet (XFontSet font_set)
{
  return XLocaleOfFontSet (font_set);
}

BOOL ContextDependentDrawing (XFontSet font_set)
{
  return XContextDependentDrawing (font_set);
}



EXT_OB X_FontSet_list_access (EXT_OB* list, INT index)
{
  return list[index];
}

#endif /* XLIBVERSION != 1104 */
