/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/30 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_Color_size (void)
{
  return (sizeof(XColor)+sizeof(INT)-1)/sizeof(INT);
}



void X_Color_pixel_set (XColor* color, INT pixel)
{ color->pixel = pixel; }

void X_Color_red_set (XColor* color, INT red)
{ color->red = red; }

void X_Color_green_set (XColor* color, INT green)
{ color->green = green; }

void X_Color_blue_set (XColor* color, INT blue)
{ color->blue = blue; }

void X_Color_flags_set (XColor* color, INT flags)
{ color->flags = flags; }



INT X_Color_pixel_get (XColor* color)
{ return color->pixel; }

INT X_Color_red_get (XColor* color)
{ return color->red; }

INT X_Color_green_get (XColor* color)
{ return color->green; }

INT X_Color_blue_get (XColor* color)
{ return color->blue; }

INT X_Color_flags_get (XColor* color)
{ return color->flags; }
