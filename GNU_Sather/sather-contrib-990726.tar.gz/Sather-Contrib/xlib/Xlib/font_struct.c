/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/05 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



XExtData* X_FontStruct_ext_data_get (XFontStruct* font_struct)
{ return font_struct->ext_data; }

INT X_FontStruct_fid_get (XFontStruct* font_struct)
{ return font_struct->fid; }

INT X_FontStruct_direction_get (XFontStruct* font_struct)
{ return font_struct->direction; }

INT X_FontStruct_min_char_or_byte2_get (XFontStruct* font_struct)
{ return font_struct->min_char_or_byte2; }

INT X_FontStruct_max_char_or_byte2_get (XFontStruct* font_struct)
{ return font_struct->max_char_or_byte2; }

INT X_FontStruct_min_byte1_get (XFontStruct* font_struct)
{ return font_struct->min_byte1; }

INT X_FontStruct_max_byte1_get (XFontStruct* font_struct)
{ return font_struct->max_byte1; }

BOOL X_FontStruct_all_chars_exist_get (XFontStruct* font_struct)
{ return font_struct->all_chars_exist; }

INT X_FontStruct_default_char_get (XFontStruct* font_struct)
{ return font_struct->default_char; }

INT X_FontStruct_n_properties_get (XFontStruct* font_struct)
{ return font_struct->n_properties; }

XFontProp* X_FontStruct_properties_get (XFontStruct* font_struct)
{ return font_struct->properties; }

XCharStruct* X_FontStruct_min_bounds_get (XFontStruct* font_struct)
{ return &(font_struct->min_bounds); }

XCharStruct* X_FontStruct_max_bounds_get (XFontStruct* font_struct)
{ return &(font_struct->max_bounds); }

XCharStruct* X_FontStruct_per_char_get (XFontStruct* font_struct)
{ return font_struct->per_char; }

INT X_FontStruct_ascent_get (XFontStruct* font_struct)
{ return font_struct->ascent; }

INT X_FontStruct_descent_get (XFontStruct* font_struct)
{ return font_struct->descent; }
