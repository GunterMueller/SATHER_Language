/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/03 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_BlackPixel (Display *display, INT screen_number)
{
  return BlackPixel (display, screen_number);
}

INT X_WhitePixel (Display *display, INT screen_number)
{
  return WhitePixel (display, screen_number);
}

INT X_DefaultColormap (Display* display, INT screen_number)
{
  return DefaultColormap (display, screen_number);
}

INT X_DefaultDepth (Display *display, INT screen_number)
{
  return DefaultDepth (display, screen_number);
}

GC X_DefaultGC (Display *display, INT screen_number)
/* GC is struct* */
{
  return DefaultGC (display, screen_number);
}

Visual* X_DefaultVisual (Display* display, INT screen_number)
{
  return DefaultVisual (display, screen_number);
}

INT X_DisplayCells (Display *display, INT screen_number)
{
  return DisplayCells (display, screen_number);
}

INT X_DisplayPlanes (Display *display, INT screen_number)
{
  return DisplayPlanes (display, screen_number);
}

INT X_RootWindow (Display *display, INT screen_number)
{
  return RootWindow (display, screen_number);
}

Screen* X_ScreenOfDisplay (Display *display, INT screen_number)
{
  return ScreenOfDisplay (display, screen_number);
}



INT X_DisplayHeight (Display* display, INT screen_number)
{
  return DisplayHeight (display, screen_number);
}

INT X_DisplayHeightMM (Display* display, INT screen_number)
{
  return DisplayHeightMM (display, screen_number);
}

INT X_DisplayWidth (Display* display, INT screen_number)
{
  return DisplayWidth (display, screen_number);
}

INT X_DisplayWidthMM (Display* display, INT screen_number)
{
  return DisplayWidthMM (display, screen_number);
}
