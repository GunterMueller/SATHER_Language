/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/12 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "header.h"



INT X_ClassHint_size (void)
{ return (sizeof(XClassHint)+sizeof(INT)-1)/sizeof(INT); }



void X_SetClassHint
  (Display* display, INT window, XClassHint* class_hint,
   CHAR* name, CHAR* class)
{
  class_hint->res_name = name;
  class_hint->res_class = class;
  XSetClassHint (display, window, class_hint);
}

BOOL X_GetClassHint
  (Display* display, INT window, XClassHint* class_hint, CHAR** str)
{
  Status res;
  res = XGetClassHint (display, window, class_hint);
  str[0] = class_hint->res_name;
  str[1] = class_hint->res_class;
  return res;
}
