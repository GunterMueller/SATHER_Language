/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/03 - 1995/04/18 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_Event_size (void)
{ return (sizeof(XEvent)+sizeof(INT)-1)/sizeof(INT); }
