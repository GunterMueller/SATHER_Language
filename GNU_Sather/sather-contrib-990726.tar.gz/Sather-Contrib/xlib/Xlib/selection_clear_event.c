/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_SelectionClearEvent_selection_set (XSelectionClearEvent* event, INT selection)
{ event->selection = selection; }

void X_SelectionClearEvent_time_set (XSelectionClearEvent* event, INT time)
{ event->time = time; }



INT X_SelectionClearEvent_selection_get (XSelectionClearEvent* event)
{ return event->selection; }

INT X_SelectionClearEvent_time_get (XSelectionClearEvent* event)
{ return event->time; }
