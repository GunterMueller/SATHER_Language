/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/08 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_PixmapFormatValues_size (void)
{
  return (sizeof(XPixmapFormatValues)+sizeof(INT)-1)/sizeof(INT);
}



void X_PixmapFormatValues_depth_set (XPixmapFormatValues* values, INT depth)
{ values->depth = depth; }

void X_PixmapFormatValues_bits_per_pixel_set (XPixmapFormatValues* values, INT bits_per_pixel)
{ values->bits_per_pixel = bits_per_pixel; }

void X_PixmapFormatValues_scanline_pad_set (XPixmapFormatValues* values, INT scanline_pad)
{ values->scanline_pad = scanline_pad; }



INT X_PixmapFormatValues_depth_get (XPixmapFormatValues* values)
{ return values->depth; }

INT X_PixmapFormatValues_bits_per_pixel_get (XPixmapFormatValues* values)
{ return values->bits_per_pixel; }

INT X_PixmapFormatValues_scanline_pad_get (XPixmapFormatValues* values)
{ return values->scanline_pad; }
