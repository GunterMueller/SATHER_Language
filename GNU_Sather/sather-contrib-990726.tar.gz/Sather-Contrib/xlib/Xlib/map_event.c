/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_MapEvent_window_set (XMapEvent* event, INT window)
{ event->window = window; }

void X_MapEvent_override_redirect_set (XMapEvent* event, BOOL override_redirect)
{ event->override_redirect = override_redirect; }



INT X_MapEvent_window_get (XMapEvent* event)
{ return event->window; }

BOOL X_MapEvent_override_redirect_get (XMapEvent* event)
{ return event->override_redirect; }
