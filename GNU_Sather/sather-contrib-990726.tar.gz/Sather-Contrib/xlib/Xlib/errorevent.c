/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ErrorEvent_type_set (XErrorEvent* event, INT type)
{ event->type = type; }

void X_ErrorEvent_display_set (XErrorEvent* event, Display* display)
{ event->display = display; }

void X_ErrorEvent_resourceid_set (XErrorEvent* event, INT resourceid)
{ event->resourceid = resourceid; }

void X_ErrorEvent_serial_set (XErrorEvent* event, INT serial)
{ event->serial = serial; }

void X_ErrorEvent_error_code_set (XErrorEvent* event, INT error_code)
{ event->error_code = error_code; }

void X_ErrorEvent_request_code_set (XErrorEvent* event, INT request_code)
{ event->request_code = request_code; }

void X_ErrorEvent_minor_code_set (XErrorEvent* event, INT minor_code)
{ event->minor_code = minor_code; }



INT X_ErrorEvent_type_get (XErrorEvent* event)
{ return event->type; }

Display* X_ErrorEvent_display_get (XErrorEvent* event)
{ return event->display; }

INT X_ErrorEvent_resourceid_get (XErrorEvent* event)
{ return event->resourceid; }

INT X_ErrorEvent_serial_get (XErrorEvent* event)
{ return event->serial; }

INT X_ErrorEvent_error_code_get (XErrorEvent* event)
{ return event->error_code; }

INT X_ErrorEvent_request_code_get (XErrorEvent* event)
{ return event->request_code; }

INT X_ErrorEvent_minor_code_get (XErrorEvent* event)
{ return event->minor_code; }
