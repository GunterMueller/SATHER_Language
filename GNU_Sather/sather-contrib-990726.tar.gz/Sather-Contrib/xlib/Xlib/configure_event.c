/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ConfigureEvent_window_set (XConfigureEvent* event, INT window)
{ event->window = window; }

void X_ConfigureEvent_x_set (XConfigureEvent* event, INT x)
{ event->x = x; }

void X_ConfigureEvent_y_set (XConfigureEvent* event, INT y)
{ event->y = y; }

void X_ConfigureEvent_width_set (XConfigureEvent* event, INT width)
{ event->width = width; }

void X_ConfigureEvent_height_set (XConfigureEvent* event, INT height)
{ event->height = height; }

void X_ConfigureEvent_border_width_set (XConfigureEvent* event, INT border_width)
{ event->border_width = border_width; }

void X_ConfigureEvent_above_set (XConfigureEvent* event, INT above)
{ event->above = above; }

void X_ConfigureEvent_override_redirect_set (XConfigureEvent* event, BOOL override_redirect)
{ event->override_redirect = override_redirect; }



INT X_ConfigureEvent_window_get (XConfigureEvent* event)
{ return event->window; }

INT X_ConfigureEvent_x_get (XConfigureEvent* event)
{ return event->x; }

INT X_ConfigureEvent_y_get (XConfigureEvent* event)
{ return event->y; }

INT X_ConfigureEvent_width_get (XConfigureEvent* event)
{ return event->width; }

INT X_ConfigureEvent_height_get (XConfigureEvent* event)
{ return event->height; }

INT X_ConfigureEvent_border_width_get (XConfigureEvent* event)
{ return event->border_width; }

INT X_ConfigureEvent_above_get (XConfigureEvent* event)
{ return event->above; }

BOOL X_ConfigureEvent_override_redirect_get (XConfigureEvent* event)
{ return event->override_redirect; }
