/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ClientMessageEvent_message_type_set (XClientMessageEvent* event, INT message_type)
{ event->message_type = message_type; }



INT X_ClientMessageEvent_message_type_get (XClientMessageEvent* event)
{ return event->message_type; }
