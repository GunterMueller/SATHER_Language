/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_KeymapEvent_key_vector_set (XKeymapEvent* event, CHAR* key_vector)
{ bcopy (key_vector, event->key_vector, 32); }



void X_KeymapEvent_key_vector_get (XKeymapEvent* event, CHAR* chars)
{ bcopy (event->key_vector, chars, 32); }
