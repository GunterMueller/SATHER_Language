/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/07 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_HostAddress_size (void)
{ return (sizeof(XHostAddress)+sizeof(INT)-1)/sizeof(INT); }



void X_HostAddress_family_set (XHostAddress* host_address, INT family)
{ host_address->family = family; }



INT X_HostAddress_family_get (XHostAddress* host_address)
{ return host_address->family; }
