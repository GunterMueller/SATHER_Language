/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_GravityEvent_window_set (XGravityEvent* event, INT window)
{ event->window = window; }

void X_GravityEvent_x_set (XGravityEvent* event, INT x)
{ event->x = x; }

void X_GravityEvent_y_set (XGravityEvent* event, INT y)
{ event->y = y; }



INT X_GravityEvent_window_get (XGravityEvent* event)
{ return event->window; }

INT X_GravityEvent_x_get (XGravityEvent* event)
{ return event->x; }

INT X_GravityEvent_y_get (XGravityEvent* event)
{ return event->y; }
