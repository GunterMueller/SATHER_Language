/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_PropertyEvent_atom_set (XPropertyEvent* event, INT atom)
{ event->atom = atom; }

void X_PropertyEvent_time_set (XPropertyEvent* event, INT time)
{ event->time = time; }

void X_PropertyEvent_state_set (XPropertyEvent* event, INT state)
{ event->state = state; }



INT X_PropertyEvent_atom_get (XPropertyEvent* event)
{ return event->atom; }

INT X_PropertyEvent_time_get (XPropertyEvent* event)
{ return event->time; }

INT X_PropertyEvent_state_get (XPropertyEvent* event)
{ return event->state; }
