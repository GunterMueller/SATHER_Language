/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/03 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"
