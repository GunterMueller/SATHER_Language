/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/08 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_SetWindowAttributes_size (void)
{ return (sizeof(XSetWindowAttributes)+sizeof(INT)-1)/sizeof(INT); }



void X_SetWindowAttributes_background_pixmap_set (XSetWindowAttributes* attributes, INT background_pixmap)
{ attributes->background_pixmap = background_pixmap; }

void X_SetWindowAttributes_background_pixel_set (XSetWindowAttributes* attributes, INT background_pixel)
{ attributes->background_pixel = background_pixel; }

void X_SetWindowAttributes_border_pixmap_set (XSetWindowAttributes* attributes, INT border_pixmap)
{ attributes->border_pixmap = border_pixmap; }

void X_SetWindowAttributes_border_pixel_set (XSetWindowAttributes* attributes, INT border_pixel)
{ attributes->border_pixel = border_pixel; }

void X_SetWindowAttributes_bit_gravity_set (XSetWindowAttributes* attributes, INT bit_gravity)
{ attributes->bit_gravity = bit_gravity; }

void X_SetWindowAttributes_win_gravity_set (XSetWindowAttributes* attributes, INT win_gravity)
{ attributes->win_gravity = win_gravity; }

void X_SetWindowAttributes_backing_store_set (XSetWindowAttributes* attributes, INT backing_store)
{ attributes->backing_store = backing_store; }

void X_SetWindowAttributes_backing_pixel_set (XSetWindowAttributes* attributes, INT backing_pixel)
{ attributes->backing_pixel = backing_pixel; }

void X_SetWindowAttributes_save_under_set (XSetWindowAttributes* attributes, BOOL save_under)
{ attributes->save_under = save_under; }

void X_SetWindowAttributes_event_mask_set (XSetWindowAttributes* attributes, INT event_mask)
{ attributes->event_mask = event_mask; }

void X_SetWindowAttributes_do_not_propagate_mask_set (XSetWindowAttributes* attributes, INT do_not_propagate_mask)
{ attributes->do_not_propagate_mask = do_not_propagate_mask; }

void X_SetWindowAttributes_override_redirect_set (XSetWindowAttributes* attributes, BOOL override_redirect)
{ attributes->override_redirect = override_redirect; }

void X_SetWindowAttributes_colormap_set (XSetWindowAttributes* attributes, INT colormap)
{ attributes->colormap = colormap; }

void X_SetWindowAttributes_cursor_set (XSetWindowAttributes* attributes, INT cursor)
{ attributes->cursor = cursor; }



INT X_SetWindowAttributes_background_pixmap_get (XSetWindowAttributes* attributes)
{ return attributes->background_pixmap; }

INT X_SetWindowAttributes_background_pixel_get (XSetWindowAttributes* attributes)
{ return attributes->background_pixel; }

INT X_SetWindowAttributes_border_pixmap_get (XSetWindowAttributes* attributes)
{ return attributes->border_pixmap; }

INT X_SetWindowAttributes_border_pixel_get (XSetWindowAttributes* attributes)
{ return attributes->border_pixel; }

INT X_SetWindowAttributes_bit_gravity_get (XSetWindowAttributes* attributes)
{ return attributes->bit_gravity; }

INT X_SetWindowAttributes_win_gravity_get (XSetWindowAttributes* attributes)
{ return attributes->win_gravity; }

INT X_SetWindowAttributes_backing_store_get (XSetWindowAttributes* attributes)
{ return attributes->backing_store; }

INT X_SetWindowAttributes_backing_pixel_get (XSetWindowAttributes* attributes)
{ return attributes->backing_pixel; }

BOOL X_SetWindowAttributes_save_under_get (XSetWindowAttributes* attributes)
{ return attributes->save_under; }

INT X_SetWindowAttributes_event_mask_get (XSetWindowAttributes* attributes)
{ return attributes->event_mask; }

INT X_SetWindowAttributes_do_not_propagate_mask_get (XSetWindowAttributes* attributes)
{ return attributes->do_not_propagate_mask; }

BOOL X_SetWindowAttributes_override_redirect_get (XSetWindowAttributes* attributes)
{ return attributes->override_redirect; }

INT X_SetWindowAttributes_colormap_get (XSetWindowAttributes* attributes)
{ return attributes->colormap; }

INT X_SetWindowAttributes_cursor_get (XSetWindowAttributes* attributes)
{ return attributes->cursor; }
