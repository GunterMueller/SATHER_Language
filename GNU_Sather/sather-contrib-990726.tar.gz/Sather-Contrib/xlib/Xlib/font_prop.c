/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/05 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



XFontProp* X_FontProp_index (XFontProp* font_prop, INT index)
{ return font_prop+index; }



INT X_FontProp_name_get (XFontProp* font_prop)
{ return font_prop->name; }

INT X_FontProp_card32_get (XFontProp* font_prop)
{ return font_prop->card32; }
