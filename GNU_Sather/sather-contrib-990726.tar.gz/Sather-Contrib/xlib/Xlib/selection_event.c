/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_SelectionEvent_selection_set (XSelectionEvent* event, INT selection)
{ event->selection = selection; }

void X_SelectionEvent_target_set (XSelectionEvent* event, INT target)
{ event->target = target; }

void X_SelectionEvent_property_set (XSelectionEvent* event, INT property)
{ event->property = property; }

void X_SelectionEvent_time_set (XSelectionEvent* event, INT time)
{ event->time = time; }



INT X_SelectionEvent_selection_get (XSelectionEvent* event)
{ return event->selection; }

INT X_SelectionEvent_target_get (XSelectionEvent* event)
{ return event->target; }

INT X_SelectionEvent_property_get (XSelectionEvent* event)
{ return event->property; }

INT X_SelectionEvent_time_get (XSelectionEvent* event)
{ return event->time; }
