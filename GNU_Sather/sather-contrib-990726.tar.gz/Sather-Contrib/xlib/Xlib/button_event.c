/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ButtonEvent_root_set (XButtonEvent* event, INT root)
{ event->root = root; }

void X_ButtonEvent_subwindow_set (XButtonEvent* event, INT subwindow)
{ event->subwindow = subwindow; }

void X_ButtonEvent_time_set (XButtonEvent* event, INT time)
{ event->time = time; }

void X_ButtonEvent_x_set (XButtonEvent* event, INT x)
{ event->x = x; }

void X_ButtonEvent_y_set (XButtonEvent* event, INT y)
{ event->y = y; }

void X_ButtonEvent_x_root_set (XButtonEvent* event, INT x_root)
{ event->x_root = x_root; }

void X_ButtonEvent_y_root_set (XButtonEvent* event, INT y_root)
{ event->y_root = y_root; }

void X_ButtonEvent_state_set (XButtonEvent* event, INT state)
{ event->state = state; }

void X_ButtonEvent_button_set (XButtonEvent* event, INT button)
{ event->button = button; }

void X_ButtonEvent_same_screen_set (XButtonEvent* event, BOOL same_screen)
{ event->same_screen = same_screen; }



INT X_ButtonEvent_root_get (XButtonEvent* event)
{ return event->root; }

INT X_ButtonEvent_subwindow_get (XButtonEvent* event)
{ return event->subwindow; }

INT X_ButtonEvent_time_get (XButtonEvent* event)
{ return event->time; }

INT X_ButtonEvent_x_get (XButtonEvent* event)
{ return event->x; }

INT X_ButtonEvent_y_get (XButtonEvent* event)
{ return event->y; }

INT X_ButtonEvent_x_root_get (XButtonEvent* event)
{ return event->x_root; }

INT X_ButtonEvent_y_root_get (XButtonEvent* event)
{ return event->y_root; }

INT X_ButtonEvent_state_get (XButtonEvent* event)
{ return event->state; }

INT X_ButtonEvent_button_get (XButtonEvent* event)
{ return event->button; }

BOOL X_ButtonEvent_same_screen_get (XButtonEvent* event)
{ return event->same_screen; }
