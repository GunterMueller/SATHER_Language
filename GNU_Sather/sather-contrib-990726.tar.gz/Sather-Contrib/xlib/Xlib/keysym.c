/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/28 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



XModifierKeymap* X_NewModifiermap (INT max_keys_per_mod)
{
  return XNewModifiermap (max_keys_per_mod);
}

XModifierKeymap* X_GetModifierMapping (Display* display)
{

  return XGetModifierMapping (display);
}

INT X_SetModifierMapping (Display* display, XModifierKeymap* modmap)
{
  return XSetModifierMapping (display, modmap);
}

XModifierKeymap* X_InsertModifiermapEntry
  (XModifierKeymap* modmap, INT keycode_entry, INT modifier)
{
  return XInsertModifiermapEntry (modmap, keycode_entry, modifier);
}

XModifierKeymap* X_DeleteModifiermapEntry
  (XModifierKeymap* modmap, INT keycode_entry, INT modifier)
{
  return XDeleteModifiermapEntry (modmap, keycode_entry, modifier);
}

void X_FreeModifiermap (XModifierKeymap* modmap)
{
  XFreeModifiermap (modmap);
}



BOOL X_IsCursorKey (KeySym keysym)
{
  return IsCursorKey (keysym);
}

BOOL X_IsFunctionKey (KeySym keysym)
{
  return IsFunctionKey (keysym);
}

BOOL X_IsKeypadKey (KeySym keysym)
{
  return IsKeypadKey (keysym);
}

BOOL X_IsMiscFunctionKey (KeySym keysym)
{
  return IsMiscFunctionKey (keysym);
}

BOOL X_IsModifierKey (KeySym keysym)
{
  return IsModifierKey (keysym);
}

BOOL X_IsPFKey (KeySym keysym)
{
  return IsPFKey (keysym);
}
