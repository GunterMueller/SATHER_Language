/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_CirculateEvent_window_set (XCirculateEvent* event, INT window)
{ event->window = window; }

void X_CirculateEvent_place_set (XCirculateEvent* event, INT place)
{ event->place = place; }



INT X_CirculateEvent_window_get (XCirculateEvent* event)
{ return event->window; }

INT X_CirculateEvent_place_get (XCirculateEvent* event)
{ return event->place; }
