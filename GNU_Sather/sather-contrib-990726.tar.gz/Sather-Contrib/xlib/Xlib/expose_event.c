/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ExposeEvent_x_set (XExposeEvent* event, INT x)
{ event->x = x; }

void X_ExposeEvent_y_set (XExposeEvent* event, INT y)
{ event->y = y; }

void X_ExposeEvent_width_set (XExposeEvent* event, INT width)
{ event->width = width; }

void X_ExposeEvent_height_set (XExposeEvent* event, INT height)
{ event->height = height; }

void X_ExposeEvent_count_set (XExposeEvent* event, INT count)
{ event->count = count; }



INT X_ExposeEvent_x_get (XExposeEvent* event)
{ return event->x; }

INT X_ExposeEvent_y_get (XExposeEvent* event)
{ return event->y; }

INT X_ExposeEvent_width_get (XExposeEvent* event)
{ return event->width; }

INT X_ExposeEvent_height_get (XExposeEvent* event)
{ return event->height; }

INT X_ExposeEvent_count_get (XExposeEvent* event)
{ return event->count; }
