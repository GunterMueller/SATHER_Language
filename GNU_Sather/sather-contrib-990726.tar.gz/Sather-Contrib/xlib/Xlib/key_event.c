/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_KeyEvent_root_set (XKeyEvent* event, INT root)
{ event->root = root; }

void X_KeyEvent_subwindow_set (XKeyEvent* event, INT subwindow)
{ event->subwindow = subwindow; }

void X_KeyEvent_time_set (XKeyEvent* event, INT time)
{ event->time = time; }

void X_KeyEvent_x_set (XKeyEvent* event, INT x)
{ event->x = x; }

void X_KeyEvent_y_set (XKeyEvent* event, INT y)
{ event->y = y; }

void X_KeyEvent_x_root_set (XKeyEvent* event, INT x_root)
{ event->x_root = x_root; }

void X_KeyEvent_y_root_set (XKeyEvent* event, INT y_root)
{ event->y_root = y_root; }

void X_KeyEvent_state_set (XKeyEvent* event, INT state)
{ event->state = state; }

void X_KeyEvent_keycode_set (XKeyEvent* event, INT keycode)
{ event->keycode = keycode; }

void X_KeyEvent_same_screen_set (XKeyEvent* event, BOOL same_screen)
{ event->same_screen = same_screen; }



INT X_KeyEvent_root_get (XKeyEvent* event)
{ return event->root; }

INT X_KeyEvent_subwindow_get (XKeyEvent* event)
{ return event->subwindow; }

INT X_KeyEvent_time_get (XKeyEvent* event)
{ return event->time; }

INT X_KeyEvent_x_get (XKeyEvent* event)
{ return event->x; }

INT X_KeyEvent_y_get (XKeyEvent* event)
{ return event->y; }

INT X_KeyEvent_x_root_get (XKeyEvent* event)
{ return event->x_root; }

INT X_KeyEvent_y_root_get (XKeyEvent* event)
{ return event->y_root; }

INT X_KeyEvent_state_get (XKeyEvent* event)
{ return event->state; }

INT X_KeyEvent_keycode_get (XKeyEvent* event)
{ return event->keycode; }

BOOL X_KeyEvent_same_screen_get (XKeyEvent* event)
{ return event->same_screen; }
