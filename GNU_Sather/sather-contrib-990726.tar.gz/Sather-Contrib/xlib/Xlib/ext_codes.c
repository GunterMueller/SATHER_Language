/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/04/17 - 1995/04/17 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_ExtCodes_extension (XExtCodes* ext_codes)
{ return ext_codes->extension; }

INT X_ExtCodes_major_opcode (XExtCodes* ext_codes)
{ return ext_codes->major_opcode; }

INT X_ExtCodes_first_event (XExtCodes* ext_codes)
{ return ext_codes->first_event; }

INT X_ExtCodes_first_error (XExtCodes* ext_codes)
{ return ext_codes->first_error; }
