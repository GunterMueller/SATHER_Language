/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/05 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_AnyEvent_type_set (XAnyEvent* event, INT type)
{ event->type = type; }

void X_AnyEvent_serial_set (XAnyEvent* event, INT serial)
{ event->serial = serial; }

void X_AnyEvent_send_event_set (XAnyEvent* event, BOOL send_event)
{ event->send_event = send_event; }

void X_AnyEvent_display_set (XAnyEvent* event, Display* display)
{ event->display = display; }

void X_AnyEvent_window_set (XAnyEvent* event, INT window)
{ event->window = window; }



INT X_AnyEvent_type_get (XAnyEvent* event)
{ return event->type; }

INT X_AnyEvent_serial_get (XAnyEvent* event)
{ return event->serial; }

BOOL X_AnyEvent_send_event_get (XAnyEvent* event)
{ return event->send_event; }

Display* X_AnyEvent_display_get (XAnyEvent* event)
{ return event->display; }

INT X_AnyEvent_window_get (XAnyEvent* event)
{ return event->window; }
