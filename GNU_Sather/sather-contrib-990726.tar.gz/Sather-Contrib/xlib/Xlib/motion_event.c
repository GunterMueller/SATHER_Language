/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_MotionEvent_root_set (XMotionEvent* event, INT root)
{ event->root = root; }

void X_MotionEvent_subwindow_set (XMotionEvent* event, INT subwindow)
{ event->subwindow = subwindow; }

void X_MotionEvent_time_set (XMotionEvent* event, INT time)
{ event->time = time; }

void X_MotionEvent_x_set (XMotionEvent* event, INT x)
{ event->x = x; }

void X_MotionEvent_y_set (XMotionEvent* event, INT y)
{ event->y = y; }

void X_MotionEvent_x_root_set (XMotionEvent* event, INT x_root)
{ event->x_root = x_root; }

void X_MotionEvent_y_root_set (XMotionEvent* event, INT y_root)
{ event->y_root = y_root; }

void X_MotionEvent_state_set (XMotionEvent* event, INT state)
{ event->state = state; }

void X_MotionEvent_is_hint_set (XMotionEvent* event, CHAR is_hint)
{ event->is_hint = is_hint; }

void X_MotionEvent_same_screen_set (XMotionEvent* event, BOOL same_screen)
{ event->same_screen = same_screen; }



INT X_MotionEvent_root_get (XMotionEvent* event)
{ return event->root; }

INT X_MotionEvent_subwindow_get (XMotionEvent* event)
{ return event->subwindow; }

INT X_MotionEvent_time_get (XMotionEvent* event)
{ return event->time; }

INT X_MotionEvent_x_get (XMotionEvent* event)
{ return event->x; }

INT X_MotionEvent_y_get (XMotionEvent* event)
{ return event->y; }

INT X_MotionEvent_x_root_get (XMotionEvent* event)
{ return event->x_root; }

INT X_MotionEvent_y_root_get (XMotionEvent* event)
{ return event->y_root; }

INT X_MotionEvent_state_get (XMotionEvent* event)
{ return event->state; }

CHAR X_MotionEvent_is_hint_get (XMotionEvent* event)
{ return event->is_hint; }

BOOL X_MotionEvent_same_screen_get (XMotionEvent* event)
{ return event->same_screen; }
