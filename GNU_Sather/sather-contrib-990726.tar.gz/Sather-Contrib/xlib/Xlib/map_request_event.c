/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_MapRequestEvent_window_set (XMapRequestEvent* event, INT window)
{ event->window = window; }



INT X_MapRequestEvent_window_get (XMapRequestEvent* event)
{ return event->window; }
