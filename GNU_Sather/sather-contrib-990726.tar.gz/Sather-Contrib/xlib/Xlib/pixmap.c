/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/03 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_CreatePixmap (Display* display, INT drawable,
		    INT width, INT height, INT depth)
{
  return XCreatePixmap (display, drawable, width, height, depth);
}

void X_FreePixmap (Display* display, INT pixmap)
{
  XFreePixmap (display, pixmap);
}
