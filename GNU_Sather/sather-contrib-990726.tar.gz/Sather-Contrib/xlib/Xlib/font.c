/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/24 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_LoadFont (Display* display, CHAR* name)
{
  return XLoadFont (display, name);
}

void X_UnloadFont (Display* display, INT font)
{
  XUnloadFont (display, font);
}
