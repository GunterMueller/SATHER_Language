/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_VisibilityEvent_state_set (XVisibilityEvent* event, INT state)
{ event->state = state; }



INT X_VisibilityEvent_state_get (XVisibilityEvent* event)
{ return event->state; }
