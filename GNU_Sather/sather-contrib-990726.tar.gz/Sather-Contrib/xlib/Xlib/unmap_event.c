/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_UnmapEvent_window_set (XUnmapEvent* event, INT window)
{ event->window = window; }

void X_UnmapEvent_from_configure_set (XUnmapEvent* event, BOOL from_configure)
{ event->from_configure = from_configure; }



INT X_UnmapEvent_window_get (XUnmapEvent* event)
{ return event->window; }

BOOL X_UnmapEvent_from_configure_get (XUnmapEvent* event)
{ return event->from_configure; }
