/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_GraphicsExposeEvent_drawable_set (XGraphicsExposeEvent* event, INT drawable)
{ event->drawable = drawable; }

void X_GraphicsExposeEvent_x_set (XGraphicsExposeEvent* event, INT x)
{ event->x = x; }

void X_GraphicsExposeEvent_y_set (XGraphicsExposeEvent* event, INT y)
{ event->y = y; }

void X_GraphicsExposeEvent_width_set (XGraphicsExposeEvent* event, INT width)
{ event->width = width; }

void X_GraphicsExposeEvent_height_set (XGraphicsExposeEvent* event, INT height)
{ event->height = height; }

void X_GraphicsExposeEvent_major_code_set (XGraphicsExposeEvent* event, INT major_code)
{ event->major_code = major_code; }

void X_GraphicsExposeEvent_minor_code_set (XGraphicsExposeEvent* event, INT minor_code)
{ event->minor_code = minor_code; }



INT X_GraphicsExposeEvent_drawable_get (XGraphicsExposeEvent* event)
{ return event->drawable; }

INT X_GraphicsExposeEvent_x_get (XGraphicsExposeEvent* event)
{ return event->x; }

INT X_GraphicsExposeEvent_y_get (XGraphicsExposeEvent* event)
{ return event->y; }

INT X_GraphicsExposeEvent_width_get (XGraphicsExposeEvent* event)
{ return event->width; }

INT X_GraphicsExposeEvent_height_get (XGraphicsExposeEvent* event)
{ return event->height; }

INT X_GraphicsExposeEvent_major_code_get (XGraphicsExposeEvent* event)
{ return event->major_code; }

INT X_GraphicsExposeEvent_minor_code_get (XGraphicsExposeEvent* event)
{ return event->minor_code; }
