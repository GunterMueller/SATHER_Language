/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/13 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include "header.h"



INT X_SizeHints_size (void)
{ return (sizeof(XSizeHints)+sizeof(INT)-1)/sizeof(INT); }



void X_SizeHints_flags_set (XSizeHints* size_hints, INT flags)
{ size_hints->flags = flags; }

void X_SizeHints_x_set (XSizeHints* size_hints, INT x)
{ size_hints->x = x; }

void X_SizeHints_y_set (XSizeHints* size_hints, INT y)
{ size_hints->y = y; }

void X_SizeHints_width_set (XSizeHints* size_hints, INT width)
{ size_hints->width = width; }

void X_SizeHints_height_set (XSizeHints* size_hints, INT height)
{ size_hints->height = height; }

void X_SizeHints_min_width_set (XSizeHints* size_hints, INT min_width)
{ size_hints->min_width = min_width; }

void X_SizeHints_min_height_set (XSizeHints* size_hints, INT min_height)
{ size_hints->min_height = min_height; }

void X_SizeHints_max_width_set (XSizeHints* size_hints, INT max_width)
{ size_hints->max_width = max_width; }

void X_SizeHints_max_height_set (XSizeHints* size_hints, INT max_height)
{ size_hints->max_height = max_height; }

void X_SizeHints_width_inc_set (XSizeHints* size_hints, INT width_inc)
{ size_hints->width_inc = width_inc; }

void X_SizeHints_height_inc_set (XSizeHints* size_hints, INT height_inc)
{ size_hints->height_inc = height_inc; }

void X_SizeHints_min_aspect_x_set (XSizeHints* size_hints, INT min_aspect_x)
{ size_hints->min_aspect.x = min_aspect_x; }

void X_SizeHints_min_aspect_y_set (XSizeHints* size_hints, INT min_aspect_y)
{ size_hints->min_aspect.y = min_aspect_y; }

void X_SizeHints_max_aspect_x_set (XSizeHints* size_hints, INT max_aspect_x)
{ size_hints->max_aspect.x = max_aspect_x; }

void X_SizeHints_max_aspect_y_set (XSizeHints* size_hints, INT max_aspect_y)
{ size_hints->max_aspect.y = max_aspect_y; }

void X_SizeHints_base_width_set (XSizeHints* size_hints, INT base_width)
{ size_hints->base_width = base_width; }

void X_SizeHints_base_height_set (XSizeHints* size_hints, INT base_height)
{ size_hints->base_height = base_height; }

void X_SizeHints_win_gravity_set (XSizeHints* size_hints, INT win_gravity)
{ size_hints->win_gravity = win_gravity; }



INT X_SizeHints_flags_get (XSizeHints* size_hints)
{ return size_hints->flags; }

INT X_SizeHints_x_get (XSizeHints* size_hints)
{ return size_hints->x; }

INT X_SizeHints_y_get (XSizeHints* size_hints)
{ return size_hints->y; }

INT X_SizeHints_width_get (XSizeHints* size_hints)
{ return size_hints->width; }

INT X_SizeHints_height_get (XSizeHints* size_hints)
{ return size_hints->height; }

INT X_SizeHints_min_width_get (XSizeHints* size_hints)
{ return size_hints->min_width; }

INT X_SizeHints_min_height_get (XSizeHints* size_hints)
{ return size_hints->min_height; }

INT X_SizeHints_max_width_get (XSizeHints* size_hints)
{ return size_hints->max_width; }

INT X_SizeHints_max_height_get (XSizeHints* size_hints)
{ return size_hints->max_height; }

INT X_SizeHints_width_inc_get (XSizeHints* size_hints)
{ return size_hints->width_inc; }

INT X_SizeHints_height_inc_get (XSizeHints* size_hints)
{ return size_hints->height_inc; }

INT X_SizeHints_min_aspect_x_get (XSizeHints* size_hints)
{ return size_hints->min_aspect.x; }

INT X_SizeHints_min_aspect_y_get (XSizeHints* size_hints)
{ return size_hints->min_aspect.y; }

INT X_SizeHints_max_aspect_x_get (XSizeHints* size_hints)
{ return size_hints->max_aspect.x; }

INT X_SizeHints_max_aspect_y_get (XSizeHints* size_hints)
{ return size_hints->max_aspect.y; }

INT X_SizeHints_base_width_get (XSizeHints* size_hints)
{ return size_hints->base_width; }

INT X_SizeHints_base_height_get (XSizeHints* size_hints)
{ return size_hints->base_height; }

INT X_SizeHints_win_gravity_get (XSizeHints* size_hints)
{ return size_hints->win_gravity; }



void X_SetWMNormalHints (Display* display, INT window, XSizeHints* hints)
{
  XSetWMNormalHints (display, window, hints);
}

BOOL X_GetWMNormalHints
  (Display* display, INT window, XSizeHints* hints, INT* ints)
{
  Status res;
  long supplied_return;
  res = XGetWMNormalHints (display, window, hints, &supplied_return);
  ints[0] = supplied_return;
  return res;
}

void X_SetWMSizeHints
 (Display* display, INT window, XSizeHints* hints, INT property)
{
  XSetWMSizeHints (display, window, hints, property);
}

BOOL X_GetWMSizeHints
  (Display* display, INT window, XSizeHints* hints, INT* ints, INT property)
{
  Status res;
  long supplied_return;
  res = XGetWMSizeHints (display, window, hints, &supplied_return, property);
  ints[0] = supplied_return;
  return res;
}
