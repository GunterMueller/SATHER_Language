/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/03/14 - 1995/03/14 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_KeyboardControl_size (void)
{ return (sizeof(XKeyboardControl)+sizeof(INT)-1)/sizeof(INT); }



void X_KeyboardControl_key_click_percent_set (XKeyboardControl* keyboard_control, INT key_click_percent)
{ keyboard_control->key_click_percent = key_click_percent; }

void X_KeyboardControl_bell_percent_set (XKeyboardControl* keyboard_control, INT bell_percent)
{ keyboard_control->bell_percent = bell_percent; }

void X_KeyboardControl_bell_pitch_set (XKeyboardControl* keyboard_control, INT bell_pitch)
{ keyboard_control->bell_pitch = bell_pitch; }

void X_KeyboardControl_bell_duration_set (XKeyboardControl* keyboard_control, INT bell_duration)
{ keyboard_control->bell_duration = bell_duration; }

void X_KeyboardControl_led_set (XKeyboardControl* keyboard_control, INT led)
{ keyboard_control->led = led; }

void X_KeyboardControl_led_mode_set (XKeyboardControl* keyboard_control, INT led_mode)
{ keyboard_control->led_mode = led_mode; }

void X_KeyboardControl_key_set (XKeyboardControl* keyboard_control, INT key)
{ keyboard_control->key = key; }

void X_KeyboardControl_auto_repeat_mode_set (XKeyboardControl* keyboard_control, INT auto_repeat_mode)
{ keyboard_control->auto_repeat_mode = auto_repeat_mode; }



INT X_KeyboardControl_key_click_percent_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->key_click_percent; }

INT X_KeyboardControl_bell_percent_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->bell_percent; }

INT X_KeyboardControl_bell_pitch_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->bell_pitch; }

INT X_KeyboardControl_bell_duration_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->bell_duration; }

INT X_KeyboardControl_led_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->led; }

INT X_KeyboardControl_led_mode_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->led_mode; }

INT X_KeyboardControl_key_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->key; }

INT X_KeyboardControl_auto_repeat_mode_get (XKeyboardControl* keyboard_control)
{ return keyboard_control->auto_repeat_mode; }
