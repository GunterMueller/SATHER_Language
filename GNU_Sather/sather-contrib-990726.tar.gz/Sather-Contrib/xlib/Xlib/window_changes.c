/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/08 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



INT X_WindowChanges_size (void)
{ return (sizeof(XWindowChanges)+sizeof(INT)-1)/sizeof(INT); }



void X_WindowChanges_x_set (XWindowChanges* changes, INT x)
{ changes->x = x; }

void X_WindowChanges_y_set (XWindowChanges* changes, INT y)
{ changes->y = y; }

void X_WindowChanges_width_set (XWindowChanges* changes, INT width)
{ changes->width = width; }

void X_WindowChanges_height_set (XWindowChanges* changes, INT height)
{ changes->height = height; }

void X_WindowChanges_border_width_set (XWindowChanges* changes, INT border_width)
{ changes->border_width = border_width; }

void X_WindowChanges_sibling_set (XWindowChanges* changes, INT sibling)
{ changes->sibling = sibling; }

void X_WindowChanges_stack_mode_set (XWindowChanges* changes, INT stack_mode)
{ changes->stack_mode = stack_mode; }



INT X_WindowChanges_x_get (XWindowChanges* changes)
{ return changes->x; }

INT X_WindowChanges_y_get (XWindowChanges* changes)
{ return changes->y; }

INT X_WindowChanges_width_get (XWindowChanges* changes)
{ return changes->width; }

INT X_WindowChanges_height_get (XWindowChanges* changes)
{ return changes->height; }

INT X_WindowChanges_border_width_get (XWindowChanges* changes)
{ return changes->border_width; }

INT X_WindowChanges_sibling_get (XWindowChanges* changes)
{ return changes->sibling; }

INT X_WindowChanges_stack_mode_get (XWindowChanges* changes)
{ return changes->stack_mode; }
