/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_CrossingEvent_root_set (XCrossingEvent* event, INT root)
{ event->root = root; }

void X_CrossingEvent_subwindow_set (XCrossingEvent* event, INT subwindow)
{ event->subwindow = subwindow; }

void X_CrossingEvent_time_set (XCrossingEvent* event, INT time)
{ event->time = time; }

void X_CrossingEvent_x_set (XCrossingEvent* event, INT x)
{ event->x = x; }

void X_CrossingEvent_y_set (XCrossingEvent* event, INT y)
{ event->y = y; }

void X_CrossingEvent_x_root_set (XCrossingEvent* event, INT x_root)
{ event->x_root = x_root; }

void X_CrossingEvent_y_root_set (XCrossingEvent* event, INT y_root)
{ event->y_root = y_root; }

void X_CrossingEvent_mode_set (XCrossingEvent* event, INT mode)
{ event->mode = mode; }

void X_CrossingEvent_detail_set (XCrossingEvent* event, INT detail)
{ event->detail = detail; }

void X_CrossingEvent_same_screen_set (XCrossingEvent* event, BOOL same_screen)
{ event->same_screen = same_screen; }

void X_CrossingEvent_focus_set (XCrossingEvent* event, BOOL focus)
{ event->focus = focus; }

void X_CrossingEvent_state_set (XCrossingEvent* event, INT state)
{ event->state = state; }



INT X_CrossingEvent_root_get (XCrossingEvent* event)
{ return event->root; }

INT X_CrossingEvent_subwindow_get (XCrossingEvent* event)
{ return event->subwindow; }

INT X_CrossingEvent_time_get (XCrossingEvent* event)
{ return event->time; }

INT X_CrossingEvent_x_get (XCrossingEvent* event)
{ return event->x; }

INT X_CrossingEvent_y_get (XCrossingEvent* event)
{ return event->y; }

INT X_CrossingEvent_x_root_get (XCrossingEvent* event)
{ return event->x_root; }

INT X_CrossingEvent_y_root_get (XCrossingEvent* event)
{ return event->y_root; }

INT X_CrossingEvent_mode_get (XCrossingEvent* event)
{ return event->mode; }

INT X_CrossingEvent_detail_get (XCrossingEvent* event)
{ return event->detail; }

BOOL X_CrossingEvent_same_screen_get (XCrossingEvent* event)
{ return event->same_screen; }

BOOL X_CrossingEvent_focus_get (XCrossingEvent* event)
{ return event->focus; }

INT X_CrossingEvent_state_get (XCrossingEvent* event)
{ return event->state; }
