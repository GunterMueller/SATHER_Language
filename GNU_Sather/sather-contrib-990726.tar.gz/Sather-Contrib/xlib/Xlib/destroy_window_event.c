/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/05 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_DestroyWindowEvent_window_set (XDestroyWindowEvent* event, INT window)
{ event->window = window; }



INT X_DestroyWindowEvent_window_get (XDestroyWindowEvent* event)
{ return event->window; }
