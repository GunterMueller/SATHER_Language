/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_SelectionRequestEvent_requestor_set (XSelectionRequestEvent* event, INT requestor)
{ event->requestor = requestor; }

void X_SelectionRequestEvent_selection_set (XSelectionRequestEvent* event, INT selection)
{ event->selection = selection; }

void X_SelectionRequestEvent_target_set (XSelectionRequestEvent* event, INT target)
{ event->target = target; }

void X_SelectionRequestEvent_property_set (XSelectionRequestEvent* event, INT property)
{ event->property = property; }

void X_SelectionRequestEvent_time_set (XSelectionRequestEvent* event, INT time)
{ event->time = time; }



INT X_SelectionRequestEvent_requestor_get (XSelectionRequestEvent* event)
{ return event->requestor; }

INT X_SelectionRequestEvent_selection_get (XSelectionRequestEvent* event)
{ return event->selection; }

INT X_SelectionRequestEvent_target_get (XSelectionRequestEvent* event)
{ return event->target; }

INT X_SelectionRequestEvent_property_get (XSelectionRequestEvent* event)
{ return event->property; }

INT X_SelectionRequestEvent_time_get (XSelectionRequestEvent* event)
{ return event->time; }
