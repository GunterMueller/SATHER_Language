/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ColormapEvent_colormap_set (XColormapEvent* event, INT colormap)
{ event->colormap = colormap; }

void X_ColormapEvent_new_set (XColormapEvent* event, BOOL new)
{ event->new = new; }

void X_ColormapEvent_state_set (XColormapEvent* event, INT state)
{ event->state = state; }



INT X_ColormapEvent_colormap_get (XColormapEvent* event)
{ return event->colormap; }

BOOL X_ColormapEvent_new_get (XColormapEvent* event)
{ return event->new; }

INT X_ColormapEvent_state_get (XColormapEvent* event)
{ return event->state; }
