/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/19 - 1995/02/19 by Erik Schnetter
 */

#ifndef XLIB_HEADER
#define XLIB_HEADER 1

/* Include Sather's standard header file,
 * where INT, CHAR, EXT_OB etc. are defined */
#include <System/header.h>

#endif /* #ifndef XLIB_HEADER */
