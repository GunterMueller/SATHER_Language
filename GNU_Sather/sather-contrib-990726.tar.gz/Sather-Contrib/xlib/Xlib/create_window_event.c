/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/01 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_CreateWindowEvent_window_set (XCreateWindowEvent* event, INT window)
{ event->window = window; }

void X_CreateWindowEvent_x_set (XCreateWindowEvent* event, INT x)
{ event->x = x; }

void X_CreateWindowEvent_y_set (XCreateWindowEvent* event, INT y)
{ event->y = y; }

void X_CreateWindowEvent_width_set (XCreateWindowEvent* event, INT width)
{ event->width = width; }

void X_CreateWindowEvent_height_set (XCreateWindowEvent* event, INT height)
{ event->height = height; }

void X_CreateWindowEvent_border_width_set (XCreateWindowEvent* event, INT border_width)
{ event->border_width = border_width; }

void X_CreateWindowEvent_override_redirect_set (XCreateWindowEvent* event, BOOL override_redirect)
{ event->override_redirect = override_redirect; }



INT X_CreateWindowEvent_window_get (XCreateWindowEvent* event)
{ return event->window; }

INT X_CreateWindowEvent_x_get (XCreateWindowEvent* event)
{ return event->x; }

INT X_CreateWindowEvent_y_get (XCreateWindowEvent* event)
{ return event->y; }

INT X_CreateWindowEvent_width_get (XCreateWindowEvent* event)
{ return event->width; }

INT X_CreateWindowEvent_height_get (XCreateWindowEvent* event)
{ return event->height; }

INT X_CreateWindowEvent_border_width_get (XCreateWindowEvent* event)
{ return event->border_width; }

BOOL X_CreateWindowEvent_override_redirect_get (XCreateWindowEvent* event)
{ return event->override_redirect; }
