/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/02/04 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



void X_ReparentEvent_window_set (XReparentEvent* event, INT window)
{ event->window = window; }

void X_ReparentEvent_parent_set (XReparentEvent* event, INT parent)
{ event->parent = parent; }

void X_ReparentEvent_x_set (XReparentEvent* event, INT x)
{ event->x = x; }

void X_ReparentEvent_y_set (XReparentEvent* event, INT y)
{ event->y = y; }

void X_ReparentEvent_override_redirect_set (XReparentEvent* event, BOOL override_redirect)
{ event->override_redirect = override_redirect; }



INT X_ReparentEvent_window_get (XReparentEvent* event)
{ return event->window; }

INT X_ReparentEvent_parent_get (XReparentEvent* event)
{ return event->parent; }

INT X_ReparentEvent_x_get (XReparentEvent* event)
{ return event->x; }

INT X_ReparentEvent_y_get (XReparentEvent* event)
{ return event->y; }

BOOL X_ReparentEvent_override_redirect_get (XReparentEvent* event)
{ return event->override_redirect; }
