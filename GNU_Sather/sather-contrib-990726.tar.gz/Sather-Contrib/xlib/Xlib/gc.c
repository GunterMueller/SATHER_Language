/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1994/11/03 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"



GC X_CreateGC (Display* display, Drawable d, INT mask, XGCValues* values)
/* GC is struct* */
{
  return XCreateGC (display, d, mask, values);
}

X_CopyGC (Display* display, GC src, INT mask, GC dest)
/* GC is struct* */
{
  XCopyGC (display, src, mask, dest);
}

X_ChangeGC (Display* display, GC gc, INT mask, XGCValues* values)
/* GC is struct* */
{
  XChangeGC (display, gc, mask, values);
}

void X_FreeGC (Display* display, GC gc)
/* GC is struct* */
{
  XFreeGC (display, gc);
}
