/* -*-C-*-
 * access to the X Window System for Sather
 * (c) 1995/01/23 - 1995/02/19 by Erik Schnetter
 */

#include <X11/Xlib.h>
#include "header.h"


#if XLIBVERSION == 1104
typedef char *XPointer;
#endif

INT X_ExtData_number (XExtData* ext_data)
{ return ext_data->number; }

XExtData* X_ExtData_next (XExtData* ext_data)
{ return ext_data->next; }

typedef int (*intpf)();
intpf X_ExtData_free_private (XExtData* ext_data)
{ return ext_data->free_private; }

XPointer X_ExtData_private_data (XExtData* ext_data)
{ return ext_data->private_data; }
