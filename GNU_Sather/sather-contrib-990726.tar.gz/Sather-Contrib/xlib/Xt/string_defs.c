/* access to the X toolkit for Sather
 * (c) 1995/01/16 - 1995/01/18 by Erik Schnetter
 */

#include <System/header.h>
#include <X11/Intrinsic.h>
#include <X11/StringDefs.h>



CHAR* Xt_NborderWidth()
{ return XtNborderWidth; }

CHAR* Xt_Ncallback()
{ return XtNcallback; }
