/* access to the X toolkit for Sather
 * (c) 1995/01/19 - 1995/01/19 by Erik Schnetter
 */

#include <System/header.h>
#include <X11/Intrinsic.h>
#include <X11/Shell.h>
#include <X11/Vendor.h>



WidgetClass Xt_compositeWidgetClass()
{ return compositeWidgetClass; }

WidgetClass Xt_constraintWidgetClass()
{ return constraintWidgetClass; }

WidgetClass Xt_coreWidgetClass()
{ return coreWidgetClass; }

WidgetClass Xt_shellWidgetClass()
{ return shellWidgetClass; }

WidgetClass Xt_vendorShellWidgetClass()
{ return vendorShellWidgetClass; }
