/* access to the X toolkit for Sather
 * (c) 1995/01/19 - 1995/01/19 by Erik Schnetter
 */

#include <System/header.h>
#include <malloc.h>



CHAR* XT_ARG_VAL_str2ext_ob (CHAR* str, INT len)
{
  char* addr = (char*) malloc (len+1);
  if (!addr)
    fprintf (stderr, "C_XT_ARG_VAL: malloc failed\n");
  bcopy (str, addr, len+1);
  return addr;
}

void XT_ARG_VAL_free (CHAR* addr)
{
  free (addr);
}
