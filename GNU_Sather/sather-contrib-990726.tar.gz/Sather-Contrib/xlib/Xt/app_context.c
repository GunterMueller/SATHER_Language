/* access to the X toolkit for Sather
 * (c) 1995/01/16 - 1995/02/05 by Erik Schnetter
 */

#include <System/header.h>
#include <X11/Intrinsic.h>
#include <alloca.h>



Widget Xt_AppInitialize
  (XtAppContext* app_context_ret, CHAR* app_class,
   CHAR* argvstr, INT* argvlen, INT num_argv,
   CHAR* fbr_str, INT* fbr_len, INT num_fbr)
{
  Widget widget;
  int argc;
  char** argv = (char**) alloca ((num_argv + 1) * sizeof (char*));
  char** fbr  = (char**) alloca ((num_fbr + 1)  * sizeof (char*));
  int i;
  
  /* command line parameters */
  for (i=num_argv; i--;) {
    argv[i] = argvstr + argvlen[i];
  }
  argv[num_argv] = NULL;
  
  /* fallback resources */
  for (i=num_fbr; i--;) {
    fbr[i] = fbr_str + fbr_len[i];
  }
  fbr[num_fbr] = NULL;
  
  argc = num_argv;
  widget = XtAppInitialize
    (app_context_ret, app_class, NULL, 0, &argc, argv, fbr, NULL, 0);
  
  return widget;
}

void Xt_AppMainLoop (XtAppContext app_context)
{
  XtAppMainLoop (app_context);
}

void Xt_DestroyApplicationContext (XtAppContext app_context)
{
  XtDestroyApplicationContext (app_context);
}
