#include "/usr/local/include/tcl.h"
#include "/usr/local/include/tk.h"

int ConstTclOk() {
  return TCL_OK;
}

int ConstTclError() {
  return TCL_ERROR;
}

void *ConstTclVolatile() {
  return TCL_VOLATILE;
}

int tclkit_cmd(ClientData user_data, Tcl_Interp *tcl, int argc, char **argv) {
  C_TCL_KIT_command(argv);
}

void delete_proc(ClientData client_data) {}

void init_tcl_kit(Tcl_Interp *tcl) {
  Tcl_CreateCommand(tcl, "sather", tclkit_cmd, NULL, delete_proc);
}

char *str_ind(char **argv, int i) {
  return argv[i];
}

char *Tcl_GetResult(Tcl_Interp *interpreter) {
  return interpreter->result;
}

